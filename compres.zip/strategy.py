from __future__ import annotations

import pandas as pd

from config import StrategyConfig


class TrendMomentumStrategy:
    """Trend-following long-only strategy using EMA, RSI, and ATR context."""

    def __init__(self, config: StrategyConfig) -> None:
        self.config = config

    def generate_signals(self, data: pd.DataFrame) -> pd.DataFrame:
        """Attach long entry and indicator-based exit signals to market data."""

        signals = data.copy()
        signals["entry_signal"] = (
            (signals["ema_fast"] > signals["ema_slow"])
            & (signals["close"] > signals["ema_fast"])
            & (signals["rsi"] > self.config.long_rsi_threshold)
        )
        signals["exit_signal"] = signals["rsi"] < self.config.exit_rsi_threshold
        return signals
